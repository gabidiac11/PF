{-
    4. este posibila aplicarea unei optimizari pentru aducerea apelurilor recursive ın pozitie de
    coada?
-}

{-
    Nu este posibil pentru ca nu putem adauga un acumulator, din cauza faptului x poate fi uneori mai mare iar alteori mai mic de cat y, ceea ce nu ne permite sa contorizam numarul de pasi
-}
