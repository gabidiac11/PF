{-
    Exercitiul 2.3. Utilizati :t pentru a afla tipurile expresiilor: True, False, True && False,
    True && (2 <= 4)
-}

{-
    interactiune:

    Prelude> :t True
    True :: Bool

    Prelude> :t False
    False :: Bool

    Prelude> :t True && False
    True && False :: Bool

    Prelude> :t True && (2 < 4)
    True && (2 < 4) :: Bool
-}