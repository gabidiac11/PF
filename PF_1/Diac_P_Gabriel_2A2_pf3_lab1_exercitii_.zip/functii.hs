id :: Char -> Char
id x = x
sumThree x y z = x + y + z
mulThree x y z = x * y * z