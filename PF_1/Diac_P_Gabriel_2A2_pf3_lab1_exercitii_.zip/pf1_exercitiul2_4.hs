{-
    Exercitiul 2.4. Utilizati :t pentru a afla tipul expresiei: "aaa".
    Cereti profesorului de laborator sa va explice tipul afisat.
-}

Prelude> :t "aaa"
"aaa" :: [Char]